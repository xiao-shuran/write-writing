# writing-craft

For Chinese writing requests, follow `.agents/skills/writing-craft/SKILL.md`. If it is missing, fall back to `skills/writing-craft/SKILL.md`, the package-root `SKILL.md`, then `.claude/skills/writing-craft/SKILL.md`.

Match intake depth to task size. Preserve verified facts and the user's voice. Route to references only when they change the result, and use `references/fallbacks.md` if a referenced file is unavailable.

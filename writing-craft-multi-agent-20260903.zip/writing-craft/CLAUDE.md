# writing-craft

For Chinese writing tasks, use `.claude/skills/writing-craft/SKILL.md` when available. Fall back to `.agents/skills/writing-craft/SKILL.md`, `skills/writing-craft/SKILL.md`, then the package-root `SKILL.md`.

Do not assume a full interview is needed for a small edit. Use the adaptive task gate, preserve confirmed facts and the user's own voice, and follow `references/fallbacks.md` when a skill file is missing. Claude Code may invoke this skill as `/writing-craft` when the platform has loaded the registered path.

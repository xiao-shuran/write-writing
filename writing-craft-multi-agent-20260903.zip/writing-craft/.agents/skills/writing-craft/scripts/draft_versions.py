#!/usr/bin/env python3
"""Create, list, compare, and safely restore local draft snapshots.

This tool is opt-in: it only writes a snapshot when explicitly invoked. It
never contacts a network service, deletes a version, or overwrites an existing
restore output.
"""

from __future__ import print_function

import argparse
import datetime as dt
import difflib
import json
import re
import shutil
import sys
from pathlib import Path


INDEX_NAME = "versions.json"


def emit(text, stream=None):
    stream = stream or sys.stdout
    payload = str(text).encode("utf-8")
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        buffer.write(payload + b"\n")
        buffer.flush()
    else:
        stream.write(payload.decode("utf-8") + "\n")


def slug(value):
    value = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip())
    return value.strip("-") or "draft"


def read_index(store_dir):
    path = store_dir / INDEX_NAME
    if not path.is_file():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RuntimeError("无法读取版本索引：%s" % error)
    if not isinstance(payload, list):
        raise RuntimeError("版本索引格式无效。")
    return payload


def write_index(store_dir, entries):
    path = store_dir / INDEX_NAME
    path.write_text(json.dumps(entries, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def character_count(path):
    return len(re.sub(r"\s+", "", path.read_text(encoding="utf-8-sig")))


def snapshot(args):
    source = Path(args.input)
    store_dir = Path(args.store_dir)
    if not source.is_file():
        raise RuntimeError("找不到稿件：%s" % source)
    store_dir.mkdir(parents=True, exist_ok=True)
    timestamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    label = slug(args.label or "draft")
    suffix = source.suffix or ".txt"
    destination = store_dir / ("%s-%s%s" % (timestamp, label, suffix))
    if destination.exists():
        raise RuntimeError("版本文件已存在：%s" % destination)
    shutil.copy2(str(source), str(destination))
    entries = read_index(store_dir)
    entries.append(
        {
            "file": destination.name,
            "created_at": dt.datetime.now().isoformat(timespec="seconds"),
            "label": args.label or "draft",
            "source": str(source),
            "mode": args.mode or "unspecified",
            "note": args.note or "",
            "character_count": character_count(destination),
        }
    )
    write_index(store_dir, entries)
    emit(json.dumps(entries[-1], ensure_ascii=False, indent=2))


def list_versions(args):
    entries = read_index(Path(args.store_dir))
    emit(json.dumps(entries, ensure_ascii=False, indent=2))


def compare(args):
    left = Path(args.left)
    right = Path(args.right)
    if not left.is_file() or not right.is_file():
        raise RuntimeError("比较文件不存在。")
    left_lines = left.read_text(encoding="utf-8-sig").splitlines(True)
    right_lines = right.read_text(encoding="utf-8-sig").splitlines(True)
    diff = difflib.unified_diff(left_lines, right_lines, fromfile=str(left), tofile=str(right))
    output = "".join(diff)
    emit(output if output else "两个版本文本相同。")


def restore(args):
    source = Path(args.snapshot)
    output = Path(args.output)
    if not source.is_file():
        raise RuntimeError("找不到版本快照：%s" % source)
    if output.exists():
        raise RuntimeError("拒绝覆盖已有输出文件：%s" % output)
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(str(source), str(output))
    emit("已恢复到新文件：%s" % output)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)

    snapshot_parser = commands.add_parser("snapshot")
    snapshot_parser.add_argument("input")
    snapshot_parser.add_argument("--store-dir", required=True)
    snapshot_parser.add_argument("--label")
    snapshot_parser.add_argument("--mode", choices=("conservative", "structural", "exploratory"))
    snapshot_parser.add_argument("--note")

    list_parser = commands.add_parser("list")
    list_parser.add_argument("--store-dir", required=True)

    compare_parser = commands.add_parser("compare")
    compare_parser.add_argument("left")
    compare_parser.add_argument("right")

    restore_parser = commands.add_parser("restore")
    restore_parser.add_argument("snapshot")
    restore_parser.add_argument("--output", required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    try:
        if args.command == "snapshot":
            snapshot(args)
        elif args.command == "list":
            list_versions(args)
        elif args.command == "compare":
            compare(args)
        elif args.command == "restore":
            restore(args)
    except RuntimeError as error:
        emit("版本操作失败：%s" % error, sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())


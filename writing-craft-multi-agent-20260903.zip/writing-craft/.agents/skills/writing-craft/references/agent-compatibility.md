# Agent 兼容与安装

本技能的写作规则只有一份权威内容，平台差异只决定 Agent 从哪里发现 `SKILL.md`。目录中的 `references/`、`scripts/` 和 `SKILL.md` 必须一起保留；只复制一个入口文件会失去按需参考、恢复和审校能力。

## 兼容矩阵

| Agent / 客户端 | 首选发现路径 | 常用调用方式 | 说明 |
|---|---|---|---|
| OpenClaw | `<workspace>/skills/writing-craft/SKILL.md` | `/skill writing-craft`，或直接提出中文写作任务 | OpenClaw 工作区会扫描 `skills/`；也可在其配置的 skills root 中放置同一目录。 |
| Claude Code（CC） | `<project>/.claude/skills/writing-craft/SKILL.md` | `/writing-craft`，或直接提出相关任务 | Claude Code 使用带 YAML frontmatter 的 `SKILL.md` 目录，并支持标准 Agent Skills 格式。 |
| Hermes Agent | `<workspace>/skills/writing-craft/SKILL.md` | 使用 Hermes 的 skill 入口或直接要求加载该 skill | Hermes 官方仓库声明兼容 `agentskills.io`；若版本或配置改变扫描目录，使用其 configured skills root。 |
| Codex / AGENTS 入口 | `<project>/.agents/skills/writing-craft/SKILL.md` | `$writing-craft` 或直接提出任务 | 保留现有项目级入口和 OpenAI UI 元数据。 |
| 其他 Agent Skills 客户端 | `<workspace>/skills/writing-craft/SKILL.md` | 按客户端的 skill 命令，或显式读取 `SKILL.md` | 只要客户端支持标准目录和 YAML frontmatter，就可复用核心内容。 |

## 从完整包安装

完整包已经包含多个同步镜像。按宿主 Agent 选择一个目录复制，**不要**把包根目录的 `AGENTS.md`、`CLAUDE.md` 或其他平台配置直接覆盖到已有项目：

```text
OpenClaw / Hermes / 通用标准客户端：skills/writing-craft/
Claude Code：.claude/skills/writing-craft/
Codex / AGENTS：.agents/skills/writing-craft/
```

复制后必须看到：

```text
writing-craft/
├── SKILL.md
├── references/
└── scripts/
```

如果只拿到一个独立的 `SKILL.md`，仍可完成最低可用写作流程，但不能假装已经加载缺失的参考文件；按 [fallbacks.md](fallbacks.md) 降级。

## 入口失效时

按当前 Agent 能访问的路径依次查找：

1. `.agents/skills/writing-craft/SKILL.md`
2. `skills/writing-craft/SKILL.md`
3. 根目录 `SKILL.md`
4. `.claude/skills/writing-craft/SKILL.md`

找到任一可读入口后，参考文件使用该入口目录下的相对路径。不要因为某个平台没有自动发现，就复制出另一套改写规则。

## 完整包维护

在包根目录运行：

```text
python scripts/skill_doctor.py --check
python scripts/skill_doctor.py --sync
```

`--sync` 以 `.agents/skills/writing-craft/` 为权威源刷新根目录、Claude 镜像和标准 `skills/` 镜像。它不会下载文件、删除文件、覆盖宿主项目配置或读取用户稿件。

## 官方格式依据

- Agent Skills specification：<https://agentskills.io/specification>
- Claude Code skills：<https://docs.anthropic.com/en/docs/claude-code/skills>
- OpenClaw creating skills：<https://docs.openclaw.ai/tools/creating-skills>
- Hermes Agent：<https://github.com/NousResearch/hermes-agent>

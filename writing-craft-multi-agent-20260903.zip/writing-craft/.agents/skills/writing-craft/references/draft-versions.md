# 稿件版本

Skill 文件的镜像同步和用户稿件版本是两件不同的事：前者保证工具可用，后者保证作者能比较、回看和恢复自己的文字。不要把用户稿件自动混入 skill 的镜像目录。

## 何时创建版本

只有用户明确提出下列任一意图时才保存本地稿件快照：

- “保存这个版本”“留个初稿”“建立版本”“帮我对比 v1/v2”。
- 需要多人/多轮改稿且用户希望保留变化。
- 用户明确要求把改写前后保存为文件。

普通润色、临时提问或单次输出不自动保存。保存前确认输入路径、版本保存目录和标签；不要把私人材料复制进 skill 源码、Git 仓库或跨 Agent 镜像。

## 推荐目录

将版本放在用户项目或用户明确的写作目录内，例如：

```text
my-article/
├── article.md
└── draft_versions/
    ├── 20260830-143000-initial.md
    ├── 20260830-152500-structure-rewrite.md
    └── versions.json
```

不要默认把版本保存到 `writing-craft/`、`.agents/`、`.claude/` 或提交到 Git。敏感稿件、采访、医疗、法律、财务和私人记录尤其要由用户选择保存位置。

## 版本元信息

每个快照最少记录：

- 基础文件或基础版本
- 保存时间
- 用户给出的标签
- 改写范围：保守修订 / 结构改写 / 探索重写
- 文体与长度契约
- 主要改动
- 材料边界或未解决问题

元信息的目标是让人理解“这版为什么存在”，不是记录用户全部隐私或聊天内容。

## 版本工作流

1. **基线**：保存用户确认的原稿或当前版本。
2. **判断**：确定本轮要改变什么，不改变什么。
3. **新稿**：创建新文件或快照，不覆盖基线。
4. **比较**：看新增、删除、结构/声音/长度/事实边界的变化。
5. **恢复**：只输出到一个新文件；原稿除非用户明确要求，不覆盖。

## 命令行工具

```text
python scripts/draft_versions.py snapshot article.md --store-dir draft_versions --label initial
python scripts/draft_versions.py list --store-dir draft_versions
python scripts/draft_versions.py compare draft_versions/v1.md draft_versions/v2.md
python scripts/draft_versions.py restore draft_versions/v1.md --output article-restored.md
```

`restore` 拒绝覆盖已有输出文件。工具不联网、不自动提交 Git、不删除版本。

## 审稿时的版本比较

比较版本不要只看“改了多少字”。重点问：

- 新版是否更清楚地完成了读者任务？
- 新增细节是否有材料依据？
- 是否删掉了重复、空话或无来源的戏剧化内容？
- 阅读体验档位是否改变，且这是用户想要的吗？
- 字数变化是否换来了更高的信息密度，而不是生硬摘要？

详细质量比较见 [quality-evaluation.md](quality-evaluation.md)。


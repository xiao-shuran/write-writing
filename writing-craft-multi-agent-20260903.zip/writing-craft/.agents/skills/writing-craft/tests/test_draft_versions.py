import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = PACKAGE_ROOT / "scripts" / "draft_versions.py"


class DraftVersionTests(unittest.TestCase):
    def run_tool(self, *args, cwd=None):
        result = subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd=str(cwd or PACKAGE_ROOT),
        )
        return result

    def test_snapshot_list_compare_and_restore_without_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            draft = root / "draft.md"
            draft.write_text("第一版。", encoding="utf-8")
            store = root / "draft_versions"

            first = self.run_tool(
                "snapshot", str(draft), "--store-dir", str(store), "--label", "initial", "--mode", "conservative"
            )
            self.assertEqual(first.returncode, 0, msg=first.stderr)
            first_payload = json.loads(first.stdout)
            first_snapshot = store / first_payload["file"]
            self.assertTrue(first_snapshot.is_file())
            self.assertEqual(first_payload["character_count"], 4)

            draft.write_text("第二版，多了一句。", encoding="utf-8")
            second = self.run_tool(
                "snapshot", str(draft), "--store-dir", str(store), "--label", "revision", "--mode", "structural"
            )
            self.assertEqual(second.returncode, 0, msg=second.stderr)
            second_snapshot = store / json.loads(second.stdout)["file"]

            listing = self.run_tool("list", "--store-dir", str(store))
            self.assertEqual(listing.returncode, 0, msg=listing.stderr)
            self.assertEqual(len(json.loads(listing.stdout)), 2)

            comparison = self.run_tool("compare", str(first_snapshot), str(second_snapshot))
            self.assertEqual(comparison.returncode, 0, msg=comparison.stderr)
            self.assertIn("第一版", comparison.stdout)
            self.assertIn("第二版", comparison.stdout)

            restored = root / "restored.md"
            restore = self.run_tool("restore", str(first_snapshot), "--output", str(restored))
            self.assertEqual(restore.returncode, 0, msg=restore.stderr)
            self.assertEqual(restored.read_text(encoding="utf-8"), "第一版。")

            repeat = self.run_tool("restore", str(first_snapshot), "--output", str(restored))
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("拒绝覆盖", repeat.stderr)

    def test_missing_input_is_reported_without_traceback(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            result = self.run_tool(
                "snapshot", "missing.md", "--store-dir", str(Path(temporary_directory) / "versions")
            )
            self.assertEqual(result.returncode, 2)
            self.assertIn("找不到稿件", result.stderr)
            self.assertNotIn("Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
